package com.example.currencyconverter;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    Spinner planetsSpinner;
    EditText amountEditText;
    Button convertButton;
    TextView resultTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        planetsSpinner = findViewById(R.id.planets_spinner);
        amountEditText = findViewById(R.id.editText4);
        convertButton = findViewById(R.id.button);
        resultTextView = findViewById(R.id.textView7);

        // Create an ArrayAdapter for the spinner
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.currencies, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        planetsSpinner.setAdapter(adapter);

        convertButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get the selected currency and amount
                String selectedCurrency = planetsSpinner.getSelectedItem().toString();
                double amount = Double.parseDouble(amountEditText.getText().toString());

                // Perform currency conversion here
                double convertedValue = performConversion(selectedCurrency, amount);

                // Display the result in the TextView
                resultTextView.setText("Result: " + convertedValue);
            }
        });
    }

    // Implement your currency conversion logic here
    private double performConversion(String currency, double amount) {
        // You should implement your currency conversion logic based on the selected currency.
        // For simplicity, let's assume a fixed conversion rate for INR to other currencies.

        double inrToUsdRate = 0.014; // 1 INR to USD
        double inrToEuroRate = 0.012; // 1 INR to Euro
        double inrToGbpRate = 0.011; // 1 INR to GBP

        double convertedValue = 0.0;

        if (currency.equals("USD")) {
            convertedValue = amount * inrToUsdRate;
        } else if (currency.equals("Euro")) {
            convertedValue = amount * inrToEuroRate;
        } else if (currency.equals("British Pound")) {
            convertedValue = amount * inrToGbpRate;
        }

        return convertedValue;
    }
}
